sap.ui.define([
    "sap/ui/core/mvc/Controller",

	"sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, MessageToast, MessageBox, Filter, FilterOperator, JSONModel) {
        "use strict";
           
        return Controller.extend("zccs.uifinancialmanagertree.controller.FinancialManagerTree", {
            onInit: function () {

				var oUIControllModel = new JSONModel({
				    busy : false,
					// order : 0,
					hasUIChanges : false,
					idEmpty : true
				});
			    this.getView().setModel(oUIControllModel, "uiControllModel");

                var oMessageManager = sap.ui.getCore().getMessageManager(),
                    oMessageModel = oMessageManager.getMessageModel(),
                    oMessageModelBinding = oMessageModel.bindList("/", undefined, [],
                    new Filter("technical", FilterOperator.EQ, true));
			    this.getView().setModel(oMessageModel, "message");

			    oMessageModelBinding.attachChange(this.onMessageBindingChange, this);
			    this._bTechnicalErrors = false;
            },

            onNew : function () {
                var oList = this.byId("idDataTable"),
                    oBinding = oList.getBinding("items"),
                    oContext = oBinding.create({
                        "id" : "",
                        "employee_id" : "",
                        "level" : "",
                        "boss_id" : ""
                    });
    
                this._setUIChanges(true);
                this.getView().getModel("uiControllModel").setProperty("/idEmpty", true);
                oList.getItems().some(function (oItem) {
                    if (oItem.getBindingContext("ApproveDataServiceModel") === oContext) {
                        oItem.focus();
                        oItem.setSelected(true);
                        return true;
                    }
                });
            },
    

            onDelete : function () {
                debugger;
                var oBinding = this.byId("idDataTable").getBinding("items");
                var oSelected = this.byId("idDataTable").getSelectedItem();
                var oBindingContext = oSelected.getBindingContext("ApproveDataServiceModel");
                if (oBinding.hasPendingChangesForPath(oBindingContext.getPath())) {
                    MessageBox.error(this._getText("deleteNotPossibleMessage"));
                    return;
                }
                if (oSelected) {
                    oSelected.getBindingContext("ApproveDataServiceModel").delete("$auto").then(function () {
                        MessageToast.show(this._getText("deletionSuccessMessage"));
                    }.bind(this), function (oError) {
                        MessageBox.error(oError.message);
                    });
                }
            },

            onInputChange : function (oEvt) {
                debugger;
                if (oEvt.getParameter("escPressed")) {
                    this._setUIChanges();
                } else {
                    this._setUIChanges(true);
                    // Check if the id in the changed table row is empty and set the appView property accordingly
                    if (oEvt.getSource().getParent().getBindingContext("ApproveDataServiceModel").getProperty("id")) {
                        this.getView().getModel("uiControllModel").setProperty("/idEmpty", false);
                    }
                }
            },

            onRefresh : function () {
                var oBinding = this.byId("idDataTable").getBinding("items");
    
                if (oBinding.hasPendingChanges()) {
                    MessageBox.error(this._getText("refreshNotPossibleMessage"));
                    return;
                }
                oBinding.refresh();
                MessageToast.show(this._getText("refreshSuccessMessage"));
            },

            onCancel : function () {
                this.byId("idDataTable").getBinding("items").resetChanges();
                this._bTechnicalErrors = false; // If there were technical errors, cancelling changes resets them.
                this._setUIChanges(false);
            },

            onSave : function () {
                debugger;
                var fnSuccess = function () {
                    this._setBusy(false);
                    MessageToast.show(this._getText("changesSentMessage"));
                    this._setUIChanges(false);
                }.bind(this);
    
                var fnError = function (oError) {
                    this._setBusy(false);
                    this._setUIChanges(false);
                    MessageBox.error(oError.message);
                }.bind(this);
    
                this._setBusy(true); // Lock UI until submitBatch is resolved.
                this.getView().getModel("ApproveDataServiceModel").submitBatch("financialManagerTreesGroup").then(fnSuccess, fnError);
                this._bTechnicalErrors = false; // If there were technical errors, a new save resets them.
            },

            onSearch() {
                var sEmployee_id = this.getView().byId("idSearchFieldEmployee_id").getValue();
                var aFilters = [];
                if (sEmployee_id) {
                    var afilter = new Filter("employee_id", FilterOperator.Contains, sEmployee_id);
                    aFilters.push(afilter);
                }

                var oTable = this.byId("idDataTable");
                var oBinding = oTable.getBinding("items");
                oBinding.filter(aFilters);

            },

            onMessageBindingChange : function (oEvent) {
                var aContexts = oEvent.getSource().getContexts(),
                    aMessages,
                    bMessageOpen = false;
    
                if (bMessageOpen || !aContexts.length) {
                    return;
                }
    
                // Extract and remove the technical messages
                aMessages = aContexts.map(function (oContext) {
                    return oContext.getObject();
                });
                sap.ui.getCore().getMessageManager().removeMessages(aMessages);
    
                this._setUIChanges(true);
                this._bTechnicalErrors = true;
                MessageBox.error(aMessages[0].message, {
                    id : "serviceErrorMessageBox",
                    onClose : function () {
                        bMessageOpen = false;
                    }
                });
    
                bMessageOpen = true;
            },

            _getText : function (sTextId, aArgs) {
                return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText(sTextId, aArgs);
            },
    
            _setUIChanges : function (bHasUIChanges) {
                if (this._bTechnicalErrors) {
                    bHasUIChanges = true;
                } else if (bHasUIChanges === undefined) {
                    bHasUIChanges = this.getView().getModel("ApproveDataServiceModel").hasPendingChanges();
                }
                debugger;
                var oModel = this.getView().getModel("uiControllModel");
                oModel.setProperty("/hasUIChanges", bHasUIChanges);
            },

            _setBusy : function (bIsBusy) {
                var oModel = this.getView().getModel("uiControllModel");
                oModel.setProperty("/busy", bIsBusy);
            }

            
        });
    });



// sap.ui.define([
//     "sap/ui/core/mvc/Controller"
// ],
//     /**
//      * @param {typeof sap.ui.core.mvc.Controller} Controller
//      */
//     function (Controller) {
//         "use strict";

//         return Controller.extend("zccs.uifinancialmanagertree.controller.FinancialManagerTree", {
//             onInit: function () {

//             }
//         });
//     });
