sap.ui.define([
	"zccs/ui_financial_manager_tree/test/unit/controller/FinancialManagerTree.controller"
], function () {
	"use strict";
});
