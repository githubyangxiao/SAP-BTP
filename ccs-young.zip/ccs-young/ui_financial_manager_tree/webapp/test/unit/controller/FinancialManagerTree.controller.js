/*global QUnit*/

sap.ui.define([
	"zccs/ui_financial_manager_tree/controller/FinancialManagerTree.controller"
], function (Controller) {
	"use strict";

	QUnit.module("FinancialManagerTree Controller");

	QUnit.test("I should test the FinancialManagerTree controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
