/* global QUnit */

sap.ui.require(["zccs/uismallclass/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
