sap.ui.define([
	"zccs/ui_small_class/test/unit/controller/SmallClass.controller"
], function () {
	"use strict";
});
