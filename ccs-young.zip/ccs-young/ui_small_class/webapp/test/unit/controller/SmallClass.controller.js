/*global QUnit*/

sap.ui.define([
	"zccs/ui_small_class/controller/SmallClass.controller"
], function (Controller) {
	"use strict";

	QUnit.module("SmallClass Controller");

	QUnit.test("I should test the SmallClass controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
