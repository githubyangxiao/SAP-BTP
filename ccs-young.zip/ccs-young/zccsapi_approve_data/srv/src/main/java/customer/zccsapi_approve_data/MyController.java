package customer.zccsapi_approve_data;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import com.amazonaws.util.json.JSONArray;
import com.amazonaws.util.json.JSONException;
import com.amazonaws.util.json.JSONObject;
import com.sap.cds.ql.Select;
import com.sap.cds.ql.cqn.CqnSelect;
import com.sap.cds.services.ErrorStatuses;
import com.sap.cds.services.ServiceException;
import com.sap.cds.services.persistence.PersistenceService;
import com.sap.cloud.sdk.cloudplatform.connectivity.DestinationAccessor;
import com.sap.cloud.sdk.cloudplatform.connectivity.HttpClientAccessor;
import com.sap.cloud.sdk.cloudplatform.connectivity.HttpDestination;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import cds.gen.approvedataservice.ApproveAmountLimits;
import cds.gen.approvedataservice.ApproveAmountLimits_;
import cds.gen.approvedataservice.ApproveLevels;
import cds.gen.approvedataservice.ApproveLevels_;
import cds.gen.approvedataservice.FinancialDefultPics;
import cds.gen.approvedataservice.FinancialDefultPics_;
import cds.gen.approvedataservice.FinancialManagerTrees;
import cds.gen.approvedataservice.FinancialManagerTrees_;
import cds.gen.approvedataservice.ProductionTypes;
import cds.gen.approvedataservice.ProductionTypes_;
import customer.zccsapi_approve_data.zstructure.ApproveData;
import customer.zccsapi_approve_data.zstructure.ZResult;
import customer.zccsapi_approve_data.zstructure.ZReturn;

@RestController

@RequestMapping(value = "/rest")
public class MyController {
    @Autowired
    PersistenceService db;

    //Method:Post
    //path:/rest/approveData
    @PostMapping("/approveData")
    @ResponseBody
    public ApproveData approveData(@RequestBody String body) throws JSONException, URISyntaxException{

        List<ZResult> rtn = new ArrayList();
        List<ZReturn> zReturn = new ArrayList();
        //接收body传进来的内容并获取它的五个属性
        JSONObject js_result = new JSONObject(body);
        String document_type = js_result.getString("document_type");
        String pic = js_result.getString("pic");
        String company_code = js_result.getString("company_code");
        String production_type = js_result.getString("production_type");
        Double amount = js_result.getDouble("amount");

        //获取传入的pic相关员工信息
        ZResult zResult = getResult(pic,document_type);
        String levelNumber = zResult.getLevel_id();
        String supervisorId = zResult.getSupervisor_id();
        int amountLimit = zResult.getAmount_limit();
        //开启无限次循环，直到签核金额大于传入金额时退出循环，从传入pic的supervisor开始
        for(;;){
            ZResult zResult1 = getResult(supervisorId,document_type);
            levelNumber = zResult1.getLevel_id();
            //赋值supervisorId以便进入下一次循环
            supervisorId = zResult1.getSupervisor_id();
            amountLimit = zResult1.getAmount_limit();
            //签核金额大于传入金额时加入签核list同时退出循环
            if(amountLimit >= amount){
                rtn.add(zResult1);
                break;
            //签核金额小于传入金额但levelNumber=-1（CSO）时加入签核list同时退出循环    
            }else{
                if(levelNumber.equals("-1")){
                    rtn.add(zResult1);
                    break;
                }else {
                    rtn.add(zResult1);
                }
            }
        }
        
        //根据传入的company获取财务PIC
        CqnSelect financialDefultPicsSel = Select.from(FinancialDefultPics_.class).columns(b -> b.employee_id()).where(b -> b.company_code().eq(company_code));
        FinancialDefultPics financialDefultPics = db.run(financialDefultPicsSel).first(FinancialDefultPics.class)
                    .orElseThrow(() -> new ServiceException(ErrorStatuses.NOT_FOUND, "Record does not exist"));

        String emplid = financialDefultPics.getEmployeeId();
        //开启无限次循环，直到boss为空时退出循环
        for(;;){
            String boss_id = getBossResult(emplid);
            if(boss_id.isEmpty()){
                ZResult zResult2 = getHrResult(emplid,document_type);
                rtn.add(zResult2);
                break;
            }else{
                ZResult zResult2 = getHrResult(emplid,document_type);
                rtn.add(zResult2);
                //boss不为空时，将bossId赋值给emplId进入下一次循环
                emplid = boss_id;
            }
        }

        //根据传入的production_type获取controller_id和cfo_id（财务默认最起码签到Controller）
        CqnSelect productionTypesSel = Select.from(ProductionTypes_.class).columns(b -> b.controller_id(),b -> b.cfo_id()).where(b -> b.production_type().eq(production_type));
        ProductionTypes productionTypes = db.run(productionTypesSel).first(ProductionTypes.class)
                    .orElseThrow(() -> new ServiceException(ErrorStatuses.NOT_FOUND, "Record does not exist"));
        String controllerId = productionTypes.getControllerId();
        String cfoId = productionTypes.getCfoId();  
        ZResult zResult3 = getControllerAndCfoResult(controllerId,document_type,"CONTROLLER"); 
        rtn.add(zResult3);   
        //如果Controller签核金额不够，继续签到CFO
        if(zResult3.getAmount_limit() < amount){
            ZResult zResult4 = getControllerAndCfoResult(cfoId,document_type,"CFO");
            rtn.add(zResult4);
        }      


        //对list Zresult的sort栏位进行升序排序
        // rtn.sort(Comparator.comparing(ZResult::getSort).thenComparing(ZResult::getGroup).reversed());
        rtn.sort(Comparator.comparing(ZResult::getSort));

        //将list ZResult赋值给listZReturn，并加上sequence
        for(int i = 0;i < rtn.size(); i ++){
            ZReturn zReturn1 = new ZReturn();
            zReturn1.setSequence(i+1);
            zReturn1.setLevel_id(rtn.get(i).getLevel_id());
            zReturn1.setLevel_name(rtn.get(i).getLevel_name());
            zReturn1.setDepartment(rtn.get(i).getDepartment());
            zReturn1.setApprover_id(rtn.get(i).getApprover_id());
            zReturn1.setApprover_name(rtn.get(i).getApprover_name());
            zReturn1.setApprover_email_address(rtn.get(i).getApprover_email_address());
            zReturn1.setApprover_login_id(rtn.get(i).getApprover_login_id());
            zReturn.add(zReturn1);
        }

        //组成json常用格式：前面加一个content
        ApproveData approveData = new ApproveData();
        approveData.setContent(zReturn);
        return approveData;
        // return zReturn;
        // return getResult(pic);
    }


    //根据传入的员工工号和document_type获取相关人员信息
    public ZResult getResult(String emplid,String document_type) throws URISyntaxException{
        ZResult zResult = new ZResult();
        //通过destination去call HrDatas获取资料
        HttpDestination approvalList = DestinationAccessor.getDestination("CommTableService").asHttp();
        HttpClient client =  HttpClientAccessor.getHttpClient(approvalList);
        URI uri = new URIBuilder()
                .setPath("/odata/v4/TableService/HrDatas")
                .setParameter("$filter", "emplid\teq\t'"+emplid+"'")
                .build();
        HttpGet httpGet = new HttpGet(uri);
//        HttpPost ;
//        HttpPut;
//        HttpDelete
        //创建客户端对象
        // HttpClient client = HttpClientBuilder.create().build();
        //执行请求 获取响应对象
        try {
            HttpResponse response = client.execute(httpGet);
            if (response.getStatusLine().getStatusCode() == 200) {
                //解析结果
                String result = EntityUtils.toString(response.getEntity());
                JSONObject js_result = new JSONObject(result); //Convert String to JSON Object
                JSONArray entityList = js_result.getJSONArray("value");
                JSONObject hrDataMessage = (JSONObject)entityList.get(0);
                // zResult.setLevel_id(hrDataMessage.getString("officer_level_a"));
                String levelNumber = hrDataMessage.getString("officer_level_a");
                zResult.setLevel_id(levelNumber);
                //根据levelNumber从ApproveLevels中获取levelName和appGroup
                CqnSelect approveLevelsSel = Select.from(ApproveLevels_.class).columns(b -> b.level_name(),b -> b.app_group()).where(b -> b.level_number().eq(levelNumber));
                ApproveLevels approveLevels = db.run(approveLevelsSel).first(ApproveLevels.class)
                            .orElseThrow(() -> new ServiceException(ErrorStatuses.NOT_FOUND, "Record does not exist"));
                zResult.setLevel_name(approveLevels.getLevelName());   
                zResult.setGroup(approveLevels.getAppGroup());  
                //如果appGroup为0，给sort赋值0，否则赋值2，签核顺序0-1-2（1属于财务部分）
                //appGroup只有0/8/9，8=CEO,9=CSO,必须保证在金额符合条件的情况下最后签核
                if(approveLevels.getAppGroup().equals("0")){
                    zResult.setSort("0");
                }else{
                    zResult.setSort("2");
                }      
                zResult.setDepartment(hrDataMessage.getString("deptid"));
                zResult.setApprover_id(emplid);
                zResult.setApprover_name(hrDataMessage.getString("name_a"));
                zResult.setApprover_email_address(hrDataMessage.getString("email_address_a"));
                zResult.setApprover_login_id(hrDataMessage.getString("email_address_a"));
                zResult.setSupervisor_id(hrDataMessage.getString("supervisor_id"));
                //如果levelName为None的话，表示没有签核金额
                //如果levelName不为None的话，从ApproveAmountLimits获取签核金额
                if(approveLevels.getLevelName().equals("None")){
                    zResult.setAmount_limit(0);
                }else{
                    CqnSelect approveAmountLimitsSel = Select.from(ApproveAmountLimits_.class).columns(b -> b.amount_limit()).where(b -> b.level().eq(approveLevels.getLevelName()).and(b.document_type().eq(document_type)));
                    ApproveAmountLimits approveAmountLimits = db.run(approveAmountLimitsSel).first(ApproveAmountLimits.class)
                                .orElseThrow(() -> new ServiceException(ErrorStatuses.NOT_FOUND, "Record does not exist"));
                    zResult.setAmount_limit(approveAmountLimits.getAmountLimit());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return zResult;
    }


    //根据传入的员工工号和document_type获取HR相关人员信息
    public ZResult getHrResult(String emplid,String document_type) throws URISyntaxException{
        ZResult zResult = new ZResult();
        HttpDestination approvalList = DestinationAccessor.getDestination("CommTableService").asHttp();
        HttpClient client =  HttpClientAccessor.getHttpClient(approvalList);
        URI uri = new URIBuilder()
                .setPath("/odata/v4/TableService/HrDatas")
                .setParameter("$filter", "emplid\teq\t'"+emplid+"'")
                .build();
        HttpGet httpGet = new HttpGet(uri);
//        HttpPost ;
//        HttpPut;
//        HttpDelete
        //创建客户端对象
        // HttpClient client = HttpClientBuilder.create().build();
        //执行请求 获取响应对象
        try {
            HttpResponse response = client.execute(httpGet);
            if (response.getStatusLine().getStatusCode() == 200) {
                //解析结果
                String result = EntityUtils.toString(response.getEntity());
                JSONObject js_result = new JSONObject(result); //Convert String to JSON Object
                JSONArray entityList = js_result.getJSONArray("value");
                JSONObject hrDataMessage = (JSONObject)entityList.get(0);
                // zResult.setLevel_id(hrDataMessage.getString("officer_level_a"));
                // String levelNumber = hrDataMessage.getString("officer_level_a");
                zResult.setLevel_id("F1");
                zResult.setLevel_name("FIN");   
                zResult.setGroup("0");  
                //签核顺序0-1-2（1属于财务部分，在一般list之后，CEO,CSO之前签核）
                zResult.setSort("1");
                zResult.setDepartment(hrDataMessage.getString("deptid"));
                zResult.setApprover_id(emplid);
                zResult.setApprover_name(hrDataMessage.getString("name_a"));
                zResult.setApprover_email_address(hrDataMessage.getString("email_address_a"));
                zResult.setApprover_login_id(hrDataMessage.getString("email_address_a"));
                zResult.setSupervisor_id(hrDataMessage.getString("supervisor_id"));
                //从ApproveAmountLimits获取签核金额(level=Fin)
                CqnSelect approveAmountLimitsSel = Select.from(ApproveAmountLimits_.class).columns(b -> b.amount_limit()).where(b -> b.level().eq("FIN").and(b.document_type().eq(document_type)));
                ApproveAmountLimits approveAmountLimits = db.run(approveAmountLimitsSel).first(ApproveAmountLimits.class)
                            .orElseThrow(() -> new ServiceException(ErrorStatuses.NOT_FOUND, "Record does not exist"));
                zResult.setAmount_limit(approveAmountLimits.getAmountLimit());
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return zResult;
    }


    //根据传入的员工工号和document_type和level获取Controller和CFO相关人员信息
    public ZResult getControllerAndCfoResult(String emplid,String document_type,String level) throws URISyntaxException{
        ZResult zResult = new ZResult();
        HttpDestination approvalList = DestinationAccessor.getDestination("CommTableService").asHttp();
        HttpClient client =  HttpClientAccessor.getHttpClient(approvalList);
        URI uri = new URIBuilder()
                .setPath("/odata/v4/TableService/HrDatas")
                .setParameter("$filter", "emplid\teq\t'"+emplid+"'")
                .build();
        HttpGet httpGet = new HttpGet(uri);
//        HttpPost ;
//        HttpPut;
//        HttpDelete
        //创建客户端对象
        // HttpClient client = HttpClientBuilder.create().build();
        //执行请求 获取响应对象
        try {
            HttpResponse response = client.execute(httpGet);
            if (response.getStatusLine().getStatusCode() == 200) {
                //解析结果
                String result = EntityUtils.toString(response.getEntity());
                JSONObject js_result = new JSONObject(result); //Convert String to JSON Object
                JSONArray entityList = js_result.getJSONArray("value");
                JSONObject hrDataMessage = (JSONObject)entityList.get(0);
                //如果level传入CONTROLLER，则为F2，传入CFO，则为F3
                if(level.equals("CONTROLLER")){
                    zResult.setLevel_id("F2");
                }else{
                    zResult.setLevel_id("F3");
                }
                zResult.setLevel_name(level);   
                zResult.setGroup("0");  
                zResult.setSort("1");
                zResult.setDepartment(hrDataMessage.getString("deptid"));
                zResult.setApprover_id(emplid);
                zResult.setApprover_name(hrDataMessage.getString("name_a"));
                zResult.setApprover_email_address(hrDataMessage.getString("email_address_a"));
                zResult.setApprover_login_id(hrDataMessage.getString("email_address_a"));
                zResult.setSupervisor_id(hrDataMessage.getString("supervisor_id"));
                //从ApproveAmountLimits获取签核金额(level=F2或者F3)
                CqnSelect approveAmountLimitsSel = Select.from(ApproveAmountLimits_.class).columns(b -> b.amount_limit()).where(b -> b.level().eq(level).and(b.document_type().eq(document_type)));
                ApproveAmountLimits approveAmountLimits = db.run(approveAmountLimitsSel).first(ApproveAmountLimits.class)
                            .orElseThrow(() -> new ServiceException(ErrorStatuses.NOT_FOUND, "Record does not exist"));
                zResult.setAmount_limit(approveAmountLimits.getAmountLimit());
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return zResult;
    }


    //根据员工工号从FinancialManagerTrees获取BOSS的员工工号
    public String getBossResult(String emplid){
        
        CqnSelect financialManagerTreesSel = Select.from(FinancialManagerTrees_.class).columns(b -> b.boss_id()).where(b -> b.employee_id().eq(emplid).and(b.level().eq("FIN")));
        FinancialManagerTrees financialManagerTrees = db.run(financialManagerTreesSel).first(FinancialManagerTrees.class)
                    .orElseThrow(() -> new ServiceException(ErrorStatuses.NOT_FOUND, "Record does not exist"));

        return financialManagerTrees.getBossId();
    }
    
}
