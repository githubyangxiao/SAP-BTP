package customer.zccsapi_approve_data.zstructure;

import java.util.List;

public class ApproveData {
    List<ZReturn> content;

    public ApproveData() {
    }

    public ApproveData(List<ZReturn> content) {
        this.content = content;
    }

    public List<ZReturn> getContent() {
        return content;
    }

    public void setContent(List<ZReturn> content) {
        this.content = content;
    }
    
}
