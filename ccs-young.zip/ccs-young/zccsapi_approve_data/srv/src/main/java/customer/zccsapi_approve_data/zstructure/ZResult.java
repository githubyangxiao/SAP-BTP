package customer.zccsapi_approve_data.zstructure;

public class ZResult {

    private String sort;
    private String group;
    private String level_id;
    private String level_name;
    private String department;
    private String approver_id;
    private String approver_name;
    private String approver_email_address;
    private String approver_login_id;
    private String supervisor_id;
    private int amount_limit;
    public ZResult() {
    }
    public ZResult(String sort, String group, String level_id, String level_name, String department,
            String approver_id, String approver_name, String approver_email_address, String approver_login_id,
            String supervisor_id, int amount_limit) {
        this.sort = sort;
        this.group = group;
        this.level_id = level_id;
        this.level_name = level_name;
        this.department = department;
        this.approver_id = approver_id;
        this.approver_name = approver_name;
        this.approver_email_address = approver_email_address;
        this.approver_login_id = approver_login_id;
        this.supervisor_id = supervisor_id;
        this.amount_limit = amount_limit;
    }
    public String getSort() {
        return sort;
    }
    public void setSort(String sort) {
        this.sort = sort;
    }
    public String getGroup() {
        return group;
    }
    public void setGroup(String group) {
        this.group = group;
    }
    public String getLevel_id() {
        return level_id;
    }
    public void setLevel_id(String level_id) {
        this.level_id = level_id;
    }
    public String getLevel_name() {
        return level_name;
    }
    public void setLevel_name(String level_name) {
        this.level_name = level_name;
    }
    public String getDepartment() {
        return department;
    }
    public void setDepartment(String department) {
        this.department = department;
    }
    public String getApprover_id() {
        return approver_id;
    }
    public void setApprover_id(String approver_id) {
        this.approver_id = approver_id;
    }
    public String getApprover_name() {
        return approver_name;
    }
    public void setApprover_name(String approver_name) {
        this.approver_name = approver_name;
    }
    public String getApprover_email_address() {
        return approver_email_address;
    }
    public void setApprover_email_address(String approver_email_address) {
        this.approver_email_address = approver_email_address;
    }
    public String getApprover_login_id() {
        return approver_login_id;
    }
    public void setApprover_login_id(String approver_login_id) {
        this.approver_login_id = approver_login_id;
    }
    public String getSupervisor_id() {
        return supervisor_id;
    }
    public void setSupervisor_id(String supervisor_id) {
        this.supervisor_id = supervisor_id;
    }
    public int getAmount_limit() {
        return amount_limit;
    }
    public void setAmount_limit(int amount_limit) {
        this.amount_limit = amount_limit;
    }
    
    
}
