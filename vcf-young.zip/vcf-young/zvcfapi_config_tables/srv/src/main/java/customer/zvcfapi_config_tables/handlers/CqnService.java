package customer.zvcfapi_config_tables.handlers;

public class CqnService {

}
