package customer.zvcfapi_config_tables.handlers;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;

import com.amazonaws.util.json.JSONArray;
import com.amazonaws.util.json.JSONException;
import com.amazonaws.util.json.JSONObject;
import com.sap.cds.ql.Select;
import com.sap.cds.ql.cqn.CqnAnalyzer;
import com.sap.cds.ql.cqn.CqnSelect;
import com.sap.cds.reflect.CdsModel;
import com.sap.cds.services.ErrorStatuses;
import com.sap.cds.services.ServiceException;
import com.sap.cds.services.handler.EventHandler;
import com.sap.cds.services.handler.annotations.On;
import com.sap.cds.services.handler.annotations.ServiceName;
import com.sap.cds.services.persistence.PersistenceService;
import com.sap.cloud.sdk.cloudplatform.connectivity.DestinationAccessor;
import com.sap.cloud.sdk.cloudplatform.connectivity.HttpClientAccessor;
import com.sap.cloud.sdk.cloudplatform.connectivity.HttpDestination;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
// import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
// import org.json.JSONArray;
// import org.json.JSONException;
// import org.json.JSONObject;
import org.springframework.stereotype.Component;
import cds.gen.getapprovallistservice.*;
//import cds.gen.vcf.*;
import cds.gen.getapprovallistservice.Input.CompanyPurchase;
import cds.gen.vcf.WorkflowConfig;
import cds.gen.vcf.WorkflowConfig_;



@Component
@ServiceName(GetApprovalListService_.CDS_NAME)
public class GetApprovalListServiceHandler implements EventHandler {
    
    @Autowired
    PersistenceService db;
    private final CqnAnalyzer analyzer;

    GetApprovalListServiceHandler(CdsModel model){
        this.analyzer = CqnAnalyzer.create(model);
    }

    @On(event = GetApprovalListContext.CDS_NAME)
    public void setResult(GetApprovalListContext context) throws JSONException{
        Input input = Input.create();
        String applicationID = context.getInput().getApplicationId();
        String vendorAccountGroup = context.getInput().getVendorAccountGroup() ;
        String appliciant = context.getInput().getApplicant();
        List<CompanyPurchase> site = context.getInput().getCompanyPurchase();


        ApprovalList approvallist = ApprovalList.create();
        
    //Set return Approval List
        
        approvallist.setApplicationId(applicationID);

        Workflow1 workflow1 = Workflow1.create();
        List<Workflow2> workflow2List = new ArrayList<>();

        // 获取申请人的Employee资料
        Employee workflow1Applicant = null;
        try {
            workflow1Applicant = getEmployee(appliciant);
        } catch (URISyntaxException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } 

        //Call Workflow config
        //1. HQ_BU -> Check by Vendor Account Group -> Get ID
        //2. HQ FIN -> get ID
        //3. MRO Manager -> Check MRO flag = Y -> Get ID by Pur_Org 
        //4. (workflow2) Site FIN -> Get ID by Company + Pur_Org 
            // Go through all input.company_purchase & get Site FIN from workflow_config
            // combine input.company_purchase into one Workflow2 by Site FIN
        //5. (workflow2) MM core User -> Check Vendor Account Group -> Get ID by Pur_Org 
            // assign MM core user to each Workflow 2
        //TBD add "AM manager" collumn to application UI -> Get HR data by input.AmManager

        // 获取申请人主管的Employee资料
        Employee workflow1Supervisor = null;
        try {
            workflow1Supervisor = getEmployee(getBoss(appliciant));
        } catch (URISyntaxException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } 

        // 获取HqFin的Employee资料
        Employee workflow1HqFin = null;
        try {
            workflow1HqFin = getEmployee(getFinAndBu("HqFin"));
        } catch (URISyntaxException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } 

        // 获取HqBu的Employee资料
        Employee workflow1HqBu = null;
        try {
            CqnSelect workflowConfigSel = Select.from(WorkflowConfig_.class).columns(b -> b.vendor_account_group()).where(b -> b.workflow_stage().eq("HqBu"));
            WorkflowConfig workflowConfig = db.run(workflowConfigSel).first(WorkflowConfig.class)
                        .orElseThrow(() -> new ServiceException(ErrorStatuses.NOT_FOUND, " Record does not exist"));
            
            if(workflowConfig.getVendorAccountGroup().contains(vendorAccountGroup)){
                workflow1HqBu = getEmployee(getFinAndBu("HqBu"));
            }
        } catch (URISyntaxException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }     

        // 获取mroManagers的Employee资料
        // 根据传入的company_purchase去call Business Rule的MRO传回Y/N
        // 如果return Y，抓取workflow config为MroManager且purchase_org被包含的pic的Employee资料
        List<Employee> mroManagers = new ArrayList<>();
        // Loop传入的company_purchase
        for(int i = 0 ; i < site.size(); i ++){
            try {
                String flag = "N";
                String company = site.get(i).getCompany();
                String purchase_org = site.get(i).getPurchaseOrg();
                String supply_type = site.get(i).getSupplyType();
                String payment_term = site.get(i).getPaymentTerm();
                String payment_period = String.valueOf(site.get(i).getPaymentPeriod());
                String mroMessage = getMro(company, purchase_org, supply_type, payment_term);
                // 根据传入的company_purchase去call Business Rule的MRO传回Y/N
                // 如果return Y，抓取workflow config为MroManager且purchase_org被包含的pic的Employee资料
                if(mroMessage.equals("Y")){
                    CqnSelect mroWorkflowConfigSel = Select.from(WorkflowConfig_.class).columns(b -> b.pic()).where(b -> b.workflow_stage().eq("MroManager").and(b.purchase_org().contains(purchase_org)));
                    WorkflowConfig mroWorkflowConfig = db.run(mroWorkflowConfigSel).first(WorkflowConfig.class)
                                .orElseThrow(() -> new ServiceException(ErrorStatuses.NOT_FOUND, "MroManager Record does not exist"));
                    Employee mroManager = null;
                    try {
                        mroManager = getEmployee(mroWorkflowConfig.getPic());
                        if(!mroManagers.contains(mroManager)){
                            mroManagers.add(mroManager);
                        }
                    } catch (URISyntaxException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }  
                } 
                // 对workflow2进行处理
                // 获取companyPurchase，从传入的company_purchase抓取资料
                List<cds.gen.getapprovallistservice.CompanyPurchase> companyPurchaseList = new ArrayList<>();
                cds.gen.getapprovallistservice.CompanyPurchase companyPurchase = cds.gen.getapprovallistservice.CompanyPurchase.create();
                companyPurchase.setCompany(company);
                companyPurchase.setPurchaseOrg(purchase_org);
                companyPurchaseList.add(companyPurchase);
                // 处理mmCoreUser
                // 抓取workflow config为MmManager且purchase_org被包含并且vendor_account_group被包含的pic的Employee资料
                // 只有当vendor_account_group为Z101是才需要回传mmCoreUser
                Employee mmCoreUser = null;
                if(vendorAccountGroup.equals("Z101")){
                    CqnSelect mmCoreUserWorkflowConfigSel = Select.from(WorkflowConfig_.class).columns(b -> b.pic()).where(b -> b.workflow_stage().eq("MmCoreUser").and(b.purchase_org().contains(purchase_org)).and(b.vendor_account_group().contains(vendorAccountGroup)));
                    WorkflowConfig mmCoreUserWorkflowConfig = db.run(mmCoreUserWorkflowConfigSel).first(WorkflowConfig.class)
                                .orElseThrow(() -> new ServiceException(ErrorStatuses.NOT_FOUND, "MmCoreUser Record does not exist"));
                    mmCoreUser = getEmployee(mmCoreUserWorkflowConfig.getPic());  
                }   
                // 处理siteFin
                // 抓取workflow config为SiteFin且purchase_org或company被包含的pic的Employee资料
                CqnSelect siteFinWorkflowConfigSel = Select.from(WorkflowConfig_.class).columns(b -> b.pic()).where(b -> b.workflow_stage().eq("SiteFin").and((b.purchase_org().contains(purchase_org)).or(b.company().contains(company))));
                WorkflowConfig siteFinWorkflowConfig = db.run(siteFinWorkflowConfigSel).first(WorkflowConfig.class)
                            .orElseThrow(() -> new ServiceException(ErrorStatuses.NOT_FOUND, "SiteFin Record does not exist"));
                Employee siteFin = getEmployee(siteFinWorkflowConfig.getPic()); 
                // 处理companyPurchase对应同一siteFin时，将其add到已存在的siteFin记录并记录flag，不再新增一条workflow2
                for(int j = 0;j < workflow2List.size(); j ++){
                    if(workflow2List.get(j).getSiteFin().equals(siteFin)){
                        workflow2List.get(j).getCompanyPurchase().add(companyPurchase);
                        //判断这一笔的manages签核人数是不是比原本的多，多的话讲原本managers的替换
                        if(getManagers(appliciant,getManager(payment_period,vendorAccountGroup),workflow1Supervisor).size() > workflow2List.get(j).getManagers().size()){
                            workflow2List.get(j).setManagers(getManagers(appliciant,getManager(payment_period,vendorAccountGroup),workflow1Supervisor));
                        }
                        flag = "Y";
                        break;
                    }
                }
                // 加入workflow2数组
                if(flag.equals("N")){
                    Workflow2 workflow2 = Workflow2.create();  
                    workflow2.setCompanyPurchase(companyPurchaseList);
                    workflow2.setMmCoreUser(mmCoreUser);
                    workflow2.setManagers(getManagers(appliciant,getManager(payment_period,vendorAccountGroup),workflow1Supervisor));
                    workflow2.setSiteFin(siteFin);
                    workflow2List.add(workflow2);
                }
            } catch (URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        // 给workflow1赋值
        workflow1.setApplicant(workflow1Applicant);
        workflow1.setSupervisor(workflow1Supervisor);
        workflow1.setHqFin(workflow1HqFin);
        workflow1.setHqBu(workflow1HqBu);
        workflow1.setMroManagers(mroManagers);

        // 给approvallist赋值
        approvallist.setWorkflow1(workflow1);
        approvallist.setWorkflow2(workflow2List);

        context.setResult(approvallist);
        context.setCompleted();
       
    }
    @On(event = TestReturnContext.CDS_NAME)
    public void testReturn(TestReturnContext context){
        TestReturnE re_string = TestReturnE.create();
        re_string.setReString(context.getInput().getApplicationId());
        context.setResult(re_string);
        context.setCompleted();
    }

    //根据员工ID从Employee中找到姓名以及邮件地址
    public Employee getEmployee(String eno) throws URISyntaxException{
        Employee employee = Employee.create();
        HttpDestination approvalList = DestinationAccessor.getDestination("CommTableService").asHttp();
        HttpClient client =  HttpClientAccessor.getHttpClient(approvalList);
        URI uri = new URIBuilder()
                .setPath("/odata/v4/TableService/HrEmployee")
                .setParameter("$filter", "ENO\teq\t'"+eno+"'")
                .build();
        HttpGet httpGet = new HttpGet(uri);
    //        HttpPost ;
    //        HttpPut;
    //        HttpDelete
        //创建客户端对象
        // HttpClient client = HttpClientBuilder.create().build();
        //执行请求 获取响应对象
        try {
            HttpResponse response = client.execute(httpGet);
            if (response.getStatusLine().getStatusCode() == 200) {
                //解析结果
                String result = EntityUtils.toString(response.getEntity());
                JSONObject jsResult = new JSONObject(result); //Convert String to JSON Object
                JSONArray entityList = jsResult.getJSONArray("value");
                JSONObject employeeMessage = (JSONObject)entityList.get(0);
                // employee.setEmployeeId(employeeMessage.getString("ENO"));
                employee.setEmployeeId(eno);
                employee.setName(employeeMessage.getString("EENAME"));
                employee.setEmail(employeeMessage.getString("EMAIL"));
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return employee;
    }


    //根据员工ID从Employee中找到Boss姓名
    public String getBoss(String eno) throws URISyntaxException{
        String boss = "";
        HttpDestination approvalList = DestinationAccessor.getDestination("CommTableService").asHttp();
        HttpClient client =  HttpClientAccessor.getHttpClient(approvalList);
        URI uri = new URIBuilder()
                .setPath("/odata/v4/TableService/HrEmployee")
                .setParameter("$filter", "ENO\teq\t'"+eno+"'")
                .build();
        HttpGet httpGet = new HttpGet(uri);
    //        HttpPost ;
    //        HttpPut;
    //        HttpDelete
        //创建客户端对象
        // HttpClient client = HttpClientBuilder.create().build();
        //执行请求 获取响应对象
        try {
            HttpResponse response = client.execute(httpGet);
            if (response.getStatusLine().getStatusCode() == 200) {
                //解析结果
                String result = EntityUtils.toString(response.getEntity());
                // System.out.println(result);
                JSONObject jsResult = new JSONObject(result); //Convert String to JSON Object
                JSONArray entityList = jsResult.getJSONArray("value");
                JSONObject employeeMessage = (JSONObject)entityList.get(0);
                boss = employeeMessage.getString("BOSS");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return boss;
    }


    //根据workflowStage从WorkflowConfig中找到pic
    public String getFinAndBu(String workflowStage) throws URISyntaxException{
        CqnSelect workflowConfigSel = Select.from(WorkflowConfig_.class).columns(b -> b.pic()).where(b -> b.workflow_stage().eq(workflowStage));
        WorkflowConfig workflowConfig = db.run(workflowConfigSel).first(WorkflowConfig.class)
                    .orElseThrow(() -> new ServiceException(ErrorStatuses.NOT_FOUND, workflowStage+" Record does not exist"));
        return workflowConfig.getPic();
    }


    //根据companyPurchase去call Business Rule得到Y或N
    //Y表示需要抓取Mro Manager的工号
    public String getMro(String company, String purchase_org, String supply_type, String payment_term) throws URISyntaxException, JSONException{
        String mro = "";
        String mroJsonString = "{\n" +
        "  \"RuleServiceId\": \"198f2933c4e6439789dacb53222e6bf7\",\n" +
        "  \"Vocabulary\": [\n" +
        "    {\n" +
        "      \"MRO_IN\" :\n" +
        "        {\n" +
        "          \"company\" : "+company+",\n" +
        "          \"purchase_org\": "+purchase_org+",\n" +
        "          \"supply_type\" : "+supply_type+",\n" +
        "          \"payment_term\" : "+payment_term+"\n" +
        "        }\n" +
        "      }\n" +
        "    ]\n" +
        "  }";
        JSONObject mroJsonObject = new JSONObject(mroJsonString); 
        HttpDestination BusinessRules = DestinationAccessor.getDestination("BUSINESS_RULES").asHttp();
        HttpClient client =  HttpClientAccessor.getHttpClient(BusinessRules);
        URI uri = null;
        try {
            uri = new URIBuilder()
                    .setPath("/rest/v2/workingset-rule-services")
                    .build();
        } catch (URISyntaxException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        HttpPost mroHttpPost = new HttpPost(uri);
        StringEntity mroStringEntity = new StringEntity(mroJsonObject.toString(), "utf-8");
        mroStringEntity.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE,
                "application/json"));
        //设置参数到请求对象中
        mroHttpPost.setEntity(mroStringEntity);
        mroHttpPost.setHeader("Content-type", "application/json");

        //执行请求 获取响应对象
        try {
            HttpResponse response = client.execute(mroHttpPost);
            if (response.getStatusLine().getStatusCode() == 200) {
                //解析结果
    //                body = EntityUtils.toString(response.getEntity());
                mro = EntityUtils.toString(response.getEntity(),"utf-8");
    //                HttpEntity entity = response.getEntity();
    //                if (entity != null) {
    //                    //按指定编码转换结果实体为String类型
    //                    body = EntityUtils.toString(entity, "utf-8");
    //                }
    //                EntityUtils.consume(entity);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        JSONObject mroResult = new JSONObject(mro); //Convert String to JSON Object
        JSONArray mroEntityList = mroResult.getJSONArray("Result");
        JSONObject mroResult1 = (JSONObject)mroEntityList.get(0);
        JSONObject mroResult2 = new JSONObject(mroResult1.getString("MRO_OUT"));
        String mroResultString = (String) mroResult2.get("MRO");
        return mroResultString;
    }
    

    //根据companyPurchase去call Business Rule得到需要manager签核的次数
    public String getManager(String payment_period, String vender_account_group) throws URISyntaxException, JSONException{
        String manager = "";
        String managerJsonString = "{\n" +
        "  \"RuleServiceId\": \"6bea2120bede4ba79518fd2d53a39380\",\n" +
        "  \"Vocabulary\": [\n" +
        "    {\n" +
        "      \"PAYMENT_TERM_IN\": \n" +
        "      {\n" +
        "        \"payment_period\" : "+payment_period+",\n" +
        "        \"vender_account_group\" : "+vender_account_group+"\n" +
        "      }\n" +
        "    }\n" +
        "\n" +
        "    ]\n" +
        "}";
        JSONObject managerJsonObject = new JSONObject(managerJsonString); 
        HttpDestination BusinessRules = DestinationAccessor.getDestination("BUSINESS_RULES").asHttp();
        HttpClient client =  HttpClientAccessor.getHttpClient(BusinessRules);
        URI uri = null;
        try {
            uri = new URIBuilder()
                    .setPath("/rest/v2/workingset-rule-services")
                    .build();
        } catch (URISyntaxException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        HttpPost managerHttpPost = new HttpPost(uri);
        StringEntity managerStringEntity = new StringEntity(managerJsonObject.toString(), "utf-8");
        managerStringEntity.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE,
                "application/json"));
        //设置参数到请求对象中
        managerHttpPost.setEntity(managerStringEntity);
        managerHttpPost.setHeader("Content-type", "application/json");

        //执行请求 获取响应对象
        try {
            HttpResponse response = client.execute(managerHttpPost);
            if (response.getStatusLine().getStatusCode() == 200) {
                //解析结果
    //                body = EntityUtils.toString(response.getEntity());
                manager = EntityUtils.toString(response.getEntity(),"utf-8");
    //                HttpEntity entity = response.getEntity();
    //                if (entity != null) {
    //                    //按指定编码转换结果实体为String类型
    //                    body = EntityUtils.toString(entity, "utf-8");
    //                }
    //                EntityUtils.consume(entity);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        JSONObject managerResult = new JSONObject(manager); //Convert String to JSON Object
        JSONArray managerEntityList = managerResult.getJSONArray("Result");
        JSONObject managerResult1 = (JSONObject)managerEntityList.get(0);
        JSONObject managerResult2 = new JSONObject(managerResult1.getString("PAYMENT_TERM_OUT"));
        String managerResultString = (String) managerResult2.get("Layer");
        return managerResultString;
    }


    //获取manager签核list
    public List<Manager> getManagers(String eno , String layer , Employee workflow1Supervisor) throws URISyntaxException{
        List<Manager> managers = new ArrayList<>();
        List<Employee> employeeTemps = new ArrayList<>();
        List<Employee> employees = new ArrayList<>();
        //如果layer传入0，则直接返回直属主管即可
        if(layer.equals("0")){
            employees.add(getEmployee(getBoss(eno)));
        //如果layer传入1或者2，则进入下面的逻辑   
        //1代表至少要签完一个部门层级并且要求部门<=5
        //2代表至少要签完两个部门层级并且要求部门<=4 
        }else{
            int count = 0;
            int deptLevel = 0;
            int deptCount = 0;
            if(layer.equals("1")){
                deptLevel = 5;
                deptCount = 1;
            }else{
                deptLevel = 4;
                deptCount = 2;
            }
            //开启无限次循环，直至满足条件时使用break退出
            for(;;){
                count++;
                String deptCode = getDept(eno);
                String deptManager = getDeptManager(deptCode);
                if(deptManager.equals(eno)){
                    deptCode = getDvcode(deptCode);
                    deptManager = getDeptManager(deptCode);
                }
                //添加CoHead主管
                employeeTemps = getCoHeadManager(deptCode, employeeTemps);
                //添加deptManager
                Employee deptManagerEmp = getEmployee(deptManager);
                employeeTemps.add(deptManagerEmp);
                //判断如果找不到部门主管的话，则只需要返回直属主管即可
                if(employeeTemps.size() == 0){
                    employees.add(getEmployee(getBoss(eno)));
                }else{
                    //检查有没有申请人或前一层级最后一位签核人的直属主管
                    //如果有的话，把他加入Approval List
                    //getEmployee(getBoss(eno)):eno的直属主管的employee资料
                    if(employeeTemps.contains(getEmployee(getBoss(eno)))){
                        employees.add(getEmployee(getBoss(eno)));
                        //如果部门主管不止一位
                        if(employeeTemps.size()>1){
                            //检查部门主管中有没有上一步骤的直属主管，如果有的话，把他加入Approval List
                            //getEmployee(getBoss(getBoss(eno))):eno的直属主管的直属主管的employee资料
                            if(employeeTemps.contains(getEmployee(getBoss(getBoss(eno))))){
                                employees.add(getEmployee(getBoss(getBoss(eno))));
                            }
                            //检查部门主要主管有没有签到，如果没有的话，把他加入Approval List
                            if(!employees.contains(deptManagerEmp)){
                                employees.add(deptManagerEmp);
                            }
                        }
                    //如果没有的话，加入所有Co-Head，以及部门主要主管
                    }else{
                        for(int k = 0 ; k < employeeTemps.size() ; k++){
                            employees.add(employeeTemps.get(k));
                        }
                    }
                }                
                //重置list，防止影响下一次循环
                employeeTemps.clear();
                //将Approval List最后一位签核者赋值给eno进入下一次循环
                eno = employees.get(employees.size()-1).getEmployeeId();
                //根据传入的level 1，2 决定是否退出循环
                //1代表至少要签完一个部门层级并且要求部门<=5
                //2代表至少要签完两个部门层级并且要求部门<=4
                if(count >= deptCount && Integer.parseInt(getDeptLevel(deptCode)) <= deptLevel){
                    break;
                }
            }
        }

        //Approval List中有重复的主管只保留一个（保留靠后的一条记录）
        //赋值给employeeTemps
        employeeTemps = employees;
        //反转数组
        Collections.reverse(employeeTemps);
        //LinkedHashSet是在一个ArrayList删除重复数据的最佳方法。LinkedHashSet在内部完成两件事：
        //删除重复数据
        //保持添加到其中的数据的顺序
        LinkedHashSet<Employee> hashSet = new LinkedHashSet<>(employeeTemps);
        //赋值给employees
        employees = new ArrayList<>(hashSet);
        //反转数组
        Collections.reverse(employees);

        int seq = 0;
        //将employees list加入managers list并且进行编号
        for(int j = 0 ; j < employees.size() ; j++){
            //如果直属主管在workflow1签了，则不要加入managers
            if(!employees.get(j).equals(workflow1Supervisor)){
                seq++;
                Manager manager = Manager.create();
                manager.setSeq(seq);
                manager.setEmployeeId(employees.get(j).getEmployeeId());
                manager.setName(employees.get(j).getName());
                manager.setEmail(employees.get(j).getEmail());
                managers.add(manager);
            }
        }
        return managers;
    }


    //根据员工ID从Employee中找到部门编码
    public String getDept(String eno) throws URISyntaxException{
        String dept = "";
        HttpDestination approvalList = DestinationAccessor.getDestination("CommTableService").asHttp();
        HttpClient client =  HttpClientAccessor.getHttpClient(approvalList);
        URI uri = new URIBuilder()
                .setPath("/odata/v4/TableService/HrEmployee")
                .setParameter("$filter", "ENO\teq\t'"+eno+"'")
                .build();
        HttpGet httpGet = new HttpGet(uri);
    //        HttpPost ;
    //        HttpPut;
    //        HttpDelete
        //创建客户端对象
        // HttpClient client = HttpClientBuilder.create().build();
        //执行请求 获取响应对象
        try {
            HttpResponse response = client.execute(httpGet);
            if (response.getStatusLine().getStatusCode() == 200) {
                //解析结果
                String result = EntityUtils.toString(response.getEntity());
                // System.out.println(result);
                JSONObject jsResult = new JSONObject(result); //Convert String to JSON Object
                JSONArray entityList = jsResult.getJSONArray("value");
                JSONObject employeeMessage = (JSONObject)entityList.get(0);
                dept = employeeMessage.getString("DEPTNO");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return dept;
    }


    //根据deptCode从HrDepartCoHead中找到部门主管
    public List<Employee> getCoHeadManager(String deptCode, List<Employee> employees) throws URISyntaxException{
        List<Employee> employeeTemps = employees;
        HttpDestination approvalList = DestinationAccessor.getDestination("CommTableService").asHttp();
        HttpClient client =  HttpClientAccessor.getHttpClient(approvalList);
        URI uri = new URIBuilder()
                .setPath("/odata/v4/TableService/HrDepartCoHead")
                .setParameter("$filter", "DEPTCODE\teq\t'"+deptCode+"'")
                .build();
        HttpGet httpGet = new HttpGet(uri);
    //        HttpPost ;
    //        HttpPut;
    //        HttpDelete
        //创建客户端对象
        // HttpClient client = HttpClientBuilder.create().build();
        //执行请求 获取响应对象
        try {
            HttpResponse response = client.execute(httpGet);
            if (response.getStatusLine().getStatusCode() == 200) {
                //解析结果
                String result = EntityUtils.toString(response.getEntity());
                // System.out.println(result);
                JSONObject jsResult = new JSONObject(result); //Convert String to JSON Object
                JSONArray entityList = jsResult.getJSONArray("value");
                for(int i = 0 ; i < entityList.length() ; i++){
                    JSONObject departCoHeadMessage = (JSONObject)entityList.get(i);
                    Employee employee = getEmployee(departCoHeadMessage.getString("MANAGER"));
                    if(getDept(departCoHeadMessage.getString("MANAGER")).equals(deptCode)){
                        employeeTemps.add(employee);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return employeeTemps;
    }


    //根据deptCode从HrDepartment中找到部门主管
    public String getDeptManager(String deptCode) throws URISyntaxException{
        String deptManager = "";
        HttpDestination approvalList = DestinationAccessor.getDestination("CommTableService").asHttp();
        HttpClient client =  HttpClientAccessor.getHttpClient(approvalList);
        URI uri = new URIBuilder()
                .setPath("/odata/v4/TableService/HrDepartment")
                .setParameter("$filter", "DEPTCODE\teq\t'"+deptCode+"'")
                .build();
        HttpGet httpGet = new HttpGet(uri);
    //        HttpPost ;
    //        HttpPut;
    //        HttpDelete
        //创建客户端对象
        // HttpClient client = HttpClientBuilder.create().build();
        //执行请求 获取响应对象
        try {
            HttpResponse response = client.execute(httpGet);
            if (response.getStatusLine().getStatusCode() == 200) {
                //解析结果
                String result = EntityUtils.toString(response.getEntity());
                // System.out.println(result);
                JSONObject jsResult = new JSONObject(result); //Convert String to JSON Object
                JSONArray entityList = jsResult.getJSONArray("value");
                JSONObject departmentMessage = (JSONObject)entityList.get(0);
                deptManager = departmentMessage.getString("MANAGER");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return deptManager;
    }


    //根据deptCode从HrDepartment中找到部门主管
    public String getDvcode(String deptCode) throws URISyntaxException{
        String dvcode = "";
        HttpDestination approvalList = DestinationAccessor.getDestination("CommTableService").asHttp();
        HttpClient client =  HttpClientAccessor.getHttpClient(approvalList);
        URI uri = new URIBuilder()
                .setPath("/odata/v4/TableService/HrDepartment")
                .setParameter("$filter", "DEPTCODE\teq\t'"+deptCode+"'")
                .build();
        HttpGet httpGet = new HttpGet(uri);
    //        HttpPost ;
    //        HttpPut;
    //        HttpDelete
        //创建客户端对象
        // HttpClient client = HttpClientBuilder.create().build();
        //执行请求 获取响应对象
        try {
            HttpResponse response = client.execute(httpGet);
            if (response.getStatusLine().getStatusCode() == 200) {
                //解析结果
                String result = EntityUtils.toString(response.getEntity());
                // System.out.println(result);
                JSONObject jsResult = new JSONObject(result); //Convert String to JSON Object
                JSONArray entityList = jsResult.getJSONArray("value");
                JSONObject departmentMessage = (JSONObject)entityList.get(0);
                dvcode = departmentMessage.getString("DVCODE");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return dvcode;
    }


    //根据deptCode从HrDepartment中找到部门层级
    public String getDeptLevel(String deptCode) throws URISyntaxException{
        String deptLevel = "";
        HttpDestination approvalList = DestinationAccessor.getDestination("CommTableService").asHttp();
        HttpClient client =  HttpClientAccessor.getHttpClient(approvalList);
        URI uri = new URIBuilder()
                .setPath("/odata/v4/TableService/HrDepartment")
                .setParameter("$filter", "DEPTCODE\teq\t'"+deptCode+"'")
                .build();
        HttpGet httpGet = new HttpGet(uri);
    //        HttpPost ;
    //        HttpPut;
    //        HttpDelete
        //创建客户端对象
        // HttpClient client = HttpClientBuilder.create().build();
        //执行请求 获取响应对象
        try {
            HttpResponse response = client.execute(httpGet);
            if (response.getStatusLine().getStatusCode() == 200) {
                //解析结果
                String result = EntityUtils.toString(response.getEntity());
                // System.out.println(result);
                JSONObject jsResult = new JSONObject(result); //Convert String to JSON Object
                JSONArray entityList = jsResult.getJSONArray("value");
                JSONObject departmentMessage = (JSONObject)entityList.get(0);
                deptLevel = departmentMessage.getString("LEVELNO");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return deptLevel;
    }
    
}



